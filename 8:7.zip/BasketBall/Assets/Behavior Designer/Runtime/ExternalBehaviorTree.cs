using UnityEngine;
using System.Collections;

namespace BehaviorDesigner.Runtime
{
    [System.Serializable]
    public class ExternalBehaviorTree : ExternalBehavior
    {
        // intentionally left blank
    }
}