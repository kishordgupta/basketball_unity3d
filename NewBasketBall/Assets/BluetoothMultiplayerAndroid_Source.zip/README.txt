Android Bluetooth Multiplayer 1.3.2
===================================

The project is a typical Android 4.0.3 (API 15) Eclipse project and should build as-is.

I insist on using the obfuscated .jar for release builds (for better code performance and security). I've prepared some scripts so you can do that easily (Windows-only currently).
1) the scripts are located in "!TOOLS\ObfuscationScript"
2) set the library jar paths in lines 4-5 of "proguard.pro" file accordingly to your Android SDK and Unity paths
3) run obfuscate.bat
4) the obfuscated release-ready .jar-file will be in "ZBluetoothMediatorLibrary\bin\BluetoothMultiplayerAndroid.jar".

There are also two additional projects - Prime31Integration and VuforiaIntegration, which are used for better intergration with Prime31's plugins and Vuforia, correspondingly.

Feel free to contact if you are having any troubles with building the code.

--
Lost Polygon
contact@lostpolygon.com