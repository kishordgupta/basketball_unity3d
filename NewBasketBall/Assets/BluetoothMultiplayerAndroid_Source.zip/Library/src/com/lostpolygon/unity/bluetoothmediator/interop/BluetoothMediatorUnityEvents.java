/*
 * Copyright (c) 2014, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.bluetoothmediator.interop;

import com.lostpolygon.unity.bluetoothmediator.interop.UnityInterop.JavaToStringConverter;

import android.bluetooth.BluetoothDevice;

/**
 * A wrapper class for Unity callbacks.
 */
public final class BluetoothMediatorUnityEvents {

	public static void onBluetoothListeningStarted() {
		UnityInterop.UnitySendMessage("onBluetoothListeningStarted", "1");
	}

	public static void onBluetoothListeningCanceled() {
		UnityInterop.UnitySendMessage("onBluetoothListeningCanceled", "1");
	}

	public static void onBluetoothAdapterEnabled() {
		UnityInterop.UnitySendMessage("onBluetoothAdapterEnabled", "1");
	}

	public static void onBluetoothAdapterEnableFailed() {
		UnityInterop.UnitySendMessage("onBluetoothAdapterEnableFailed", "1");
	}
	
	public static void onBluetoothDiscoverabilityEnableFailed() {
		UnityInterop.UnitySendMessage("onBluetoothDiscoverabilityEnableFailed", "1");
	}
	
	public static void onBluetoothDiscoverabilityEnabled(int discoverabilityDuration) {
		UnityInterop.UnitySendMessage("onBluetoothDiscoverabilityEnabled", Integer.toString(discoverabilityDuration));
	}

	public static void onBluetoothAdapterDisabled() {
		UnityInterop.UnitySendMessage("onBluetoothAdapterDisabled", "1");
	}

	public static void onBluetoothConnectedToServer(BluetoothDevice device) {
		UnityInterop.UnitySendMessage("onBluetoothConnectedToServer", JavaToStringConverter.BluetoothDevice(device));
	}

	public static void onBluetoothConnectToServerFailed(BluetoothDevice device) {
		UnityInterop.UnitySendMessage("onBluetoothConnectToServerFailed", JavaToStringConverter.BluetoothDevice(device));
	}

	public static void onBluetoothDisconnectedFromServer(BluetoothDevice device) {
		UnityInterop.UnitySendMessage("onBluetoothDisconnectedFromServer",
										JavaToStringConverter.BluetoothDevice(device));
	}

	public static void onBluetoothClientConnected(BluetoothDevice device) {
		UnityInterop.UnitySendMessage("onBluetoothClientConnected", JavaToStringConverter.BluetoothDevice(device));
	}

	public static void onBluetoothClientDisconnected(BluetoothDevice device) {
		UnityInterop.UnitySendMessage("onBluetoothClientDisconnected", JavaToStringConverter.BluetoothDevice(device));
	}

	public static void onBluetoothDevicePicked(BluetoothDevice device) {
		UnityInterop.UnitySendMessage("onBluetoothDevicePicked", JavaToStringConverter.BluetoothDevice(device));
	}

	public static void onBluetoothDiscoveryStarted() {
		UnityInterop.UnitySendMessage("onBluetoothDiscoveryStarted", "1");
	}

	public static void onBluetoothDiscoveryFinished() {
		UnityInterop.UnitySendMessage("onBluetoothDiscoveryFinished", "1");
	}

	public static void onBluetoothDiscoveryDeviceFound(BluetoothDevice device) {
		UnityInterop.UnitySendMessage("onBluetoothDiscoveryDeviceFound", JavaToStringConverter.BluetoothDevice(device));
	}

}
