/*
 * Copyright (c) 2014, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.bluetoothmediator;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;

import android.Manifest.permission;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Configuration;

import com.lostpolygon.unity.bluetoothmediator.interop.BluetoothMediatorUnityEvents;
import com.lostpolygon.unity.bluetoothmediator.interop.LogHelper;
import com.lostpolygon.unity.bluetoothmediator.interop.UnityInterop;
import com.unity3d.player.UnityPlayer;

/**
 * The central class that provides convenient interface to the plugin. Unity must only use this one.
 */
public class BluetoothMediator implements IBluetoothMediatorCallback {
	// Intent ID's
	public static final int REQUEST_ENABLE_BT = 1;
	public static final int REQUEST_CHOOSE_DEVICE = 2;
	public static final int REQUEST_ENABLE_DISCOVERABILITY = 3;

	/** Local Bluetooth adapter. */
	private static BluetoothAdapter mAdapter = null;

	/** The context in which plugin runs. Must usually target to main Unity activity. */
	private static Activity mContext;

	/** Receives the Bluetooth adapter change events. */
	private volatile BluetoothStateChangeReceiver mBluetoothStateChangeReceiver;

	/** Receives the events of Bluetooth device picker Activity. */
	private volatile BluetoothDevicePickerReceiver mBluetoothPickerReceiver;

	/**
	 * Defines the possible states of the mediator.
	 */
	private enum MediatorMode {
		None,
		Server,
		Client
	}

	/** Current mediator mode. */
	private volatile MediatorMode mMediatorMode = MediatorMode.None;

	/** Tunneling server instance. */
	private volatile BluetoothMediatorServer mServer;

	/** Tunneling client instance. */
	private volatile BluetoothMediatorClient mClient;

	/**
	 * Holds some public settings that can be safely passed everywhere.
	 */
	public final class MediatorSettings {

		/** Remote hostname for UDP tunneling. */
		public String remoteHost;

		/** Remote port for UDP tunneling. */
		public int remotePort;

		/** Bluetooth connection UUID. Must be unique for each game. */
		public UUID uuid;

		/** The server device client has to connect to. */
		public BluetoothDevice hostDevice;

		/**
		 * Must always be set to true when working with Unity networking. Set to false to use raw
		 * data packets.
		 */
		public boolean usePacketSeparation;
	}

	/** The public MediatorSettings instance. */
	private MediatorSettings mSettings;

	/** Whether the mediator can run on current device. */
	private boolean mIsMediatorAvailable = true;

	/** The BluetoothMediator singleton instance. */
	private static BluetoothMediator mInstance;

	/** Whether the verbose logging is used. */
	private static boolean mIsVerboseLog = false;

	/**
	 * Gets the BluetoothMediator singleton. Only used from Unity.
	 * 
	 * @return the BluetoothMediator singleton
	 */
	public synchronized static BluetoothMediator getSingleton()
	{
		if (mInstance == null) {
			try {
				Activity unityActivity = UnityPlayer.currentActivity;
				return getSingleton(unityActivity);
			} catch (Exception e) {
				LogHelper.logError("Exception while retrieving UnityPlayer.currentActivity", BluetoothMediator.class, e);
			}
		}

		return mInstance;
	}

	/**
	 * Gets the BluetoothMediator singleton.
	 * 
	 * @param context
	 *            the context to run BluetoothMediator with
	 * @return the BluetoothMediator singleton
	 */
	public synchronized static BluetoothMediator getSingleton(Activity context)
	{
		if (mInstance == null)
			mInstance = new BluetoothMediator(context);

		return mInstance;
	}

	/**
	 * Called from context Activity.onActivityResult().
	 * 
	 * @param requestCode
	 *            the request code
	 * @param resultCode
	 *            the result code
	 * @param data
	 *            the data
	 */
	public synchronized static void onActivityResult(int requestCode, int resultCode, Intent data) {
		// Passing the data to the BluetoothMediator mInstance
		if (mInstance != null)
			mInstance.onActivityResultProcess(requestCode, resultCode, data);
	}

	/**
	 * Sets the state of verbose logging.
	 * 
	 * @param isEnabled
	 *            the new state of verbose logging
	 */
	public static void setVerboseLog(boolean isEnabled) {
		mIsVerboseLog = isEnabled;
	}

	/**
	 * Checks the state of verbose logging.
	 * 
	 * @return true, if verbose log is enabled
	 */
	public static boolean isVerboseLog() {
		return mIsVerboseLog;
	}

	/**
	 * Instantiates a new Bluetooth mediator instance.
	 * 
	 * @param context
	 *            the context
	 */
	private BluetoothMediator(Activity context) {
		mContext = context;

		// Check for Bluetooth permissions
		PackageManager pm = mContext.getPackageManager();
		if (context == null
			||
			!(pm.checkPermission(permission.BLUETOOTH, mContext.getPackageName()) == PackageManager.PERMISSION_GRANTED &&
			pm.checkPermission(permission.BLUETOOTH_ADMIN, mContext.getPackageName()) == PackageManager.PERMISSION_GRANTED)) {

			mIsMediatorAvailable = false;
			LogHelper.log("BLUETOOTH and BLUETOOTH_ADMIN permissions not granted. Check AndroidManifest.xml", this);

			return;
		}

		try {
			mAdapter = BluetoothAdapter.getDefaultAdapter();
		} catch (Exception e) {
			mAdapter = null;
		}

		// Creating default settings
		mSettings = new MediatorSettings();
		mSettings.usePacketSeparation = true;
		mSettings.uuid = UUID.fromString("8ce255c1-200a-11e0-ac64-0800200c9a66");

		// If the adapter is null, then Bluetooth is not supported
		if (mAdapter == null || context == null) {
			mIsMediatorAvailable = false;
			LogHelper.log("Bluetooth is not available or passed Activity is null", this);

			return;
		}

		mBluetoothStateChangeReceiver = new BluetoothStateChangeReceiver();

		// Adapter state change receiver
		IntentFilter bluetoothStateChangedFilter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
		mContext.registerReceiver(mBluetoothStateChangeReceiver, bluetoothStateChangedFilter);

		// Device picker receiver
		mBluetoothPickerReceiver = new BluetoothDevicePickerReceiver();
		IntentFilter deviceSelectedFilter = new IntentFilter();
		deviceSelectedFilter.addAction(IBluetoothDevicePicker.ACTION_DEVICE_SELECTED);

		mContext.registerReceiver(mBluetoothPickerReceiver, deviceSelectedFilter);
	}

	/**
	 * @see java.lang.Object#finalize()
	 */
	protected void finalize() {
		if (!mIsMediatorAvailable)
			return;

		stop();

		if (mAdapter != null && mAdapter.isDiscovering())
			mAdapter.cancelDiscovery();

		mContext.unregisterReceiver(mBluetoothStateChangeReceiver);
		mContext.unregisterReceiver(mDiscoveryReceiver);
		mContext.unregisterReceiver(mBluetoothPickerReceiver);
	}

	/**
	 * Sets the Bluetooth service UUID.
	 * 
	 * @param uuid
	 *            the UUID
	 * @return true, if successful
	 */
	public boolean initUuid(String uuid) {
		if (!mIsMediatorAvailable)
			return false;

		try {
			mSettings.uuid = UUID.fromString(uuid);
		} catch (IllegalArgumentException e) {
			return false;
		}

		return true;
	}

	/**
	 * Start a Bluetooth server, listening for incoming Bluetooth connections.
	 * 
	 * @param remoteHost
	 *            the remote hostname for UDP tunneling
	 * @param remotePort
	 *            the remote port for UDP tunneling
	 * @return true, if successful
	 */
	public synchronized boolean startServer(String remoteHost, int remotePort) {
		if (!mIsMediatorAvailable || !isBluetoothEnabled())
			return false;

		stop();
		if (mServer != null)
			mServer.stop(true);

		mMediatorMode = MediatorMode.Server;

		mSettings.remoteHost = remoteHost;
		mSettings.remotePort = remotePort;

		mServer = new BluetoothMediatorServer(this);
		mServer.start();

		return true;
	}

	/**
	 * Start the Bluetooth client and try to connect to the server.
	 * 
	 * @param remoteHost
	 *            the remote hostname for UDP tunneling
	 * @param remotePort
	 *            the remote port for UDP tunneling
	 * @param hostDeviceAddress
	 *            the host BluetoothDevice address
	 * @return true, if successful
	 */
	public synchronized boolean startClient(String remoteHost, int remotePort, String hostDeviceAddress) {
		if (!mIsMediatorAvailable || !isBluetoothEnabled())
			return false;

		stop();
		if (mClient != null)
			mClient.stop();

		mMediatorMode = MediatorMode.Client;

		mSettings.remoteHost = remoteHost;
		mSettings.remotePort = remotePort;
		mSettings.hostDevice = mAdapter.getRemoteDevice(hostDeviceAddress);

		mClient = new BluetoothMediatorClient(this);
		mClient.start();

		return true;
	}

	/**
	 * Stop all connectivity.
	 * 
	 * @return true, if successful
	 */
	public synchronized boolean stop() {
		if (!mIsMediatorAvailable)
			return false;

		switch (mMediatorMode) {
		case Client:
			if (mClient != null)
			{
				mClient.stop();
				mClient = null;
			}
			break;
		case Server:
			if (mServer != null)
			{
				mServer.stop(true);
				mServer = null;
			}
			break;
		default:
			break;
		}

		mMediatorMode = MediatorMode.None;

		stopDiscovery(false);

		return true;
	}

	/**
	 * Gets the current mediator mode.
	 * 
	 * @return the current mediator mode
	 */
	public byte getCurrentMode() {
		switch (mMediatorMode) {
		case Client:
			return 2;
		case Server:
			return 1;
		default:
			return 0;
		}
	}

	/**
	 * Sets whether to use raw packets.
	 * 
	 * @param isEnabled
	 *            whether to use raw packets
	 * @return true, if successful
	 */
	public boolean setRawPackets(boolean isEnabled) {
		if (mMediatorMode != MediatorMode.None)
			return false;

		mSettings.usePacketSeparation = !isEnabled;

		return true;
	}

	/**
	 * Gets the BluetoothAdapter instance.
	 * 
	 * @see com.lostpolygon.unity.bluetoothmediator.IBluetoothMediatorCallback#getAdapter()
	 */
	public synchronized BluetoothAdapter getAdapter() {
		return mAdapter;
	}

	/**
	 * Gets the mediator settings.
	 * 
	 * @see com.lostpolygon.unity.bluetoothmediator.IBluetoothMediatorCallback#getSettings()
	 */
	public synchronized MediatorSettings getSettings() {
		return mSettings;
	}

	/**
	 * Stop listening for new incoming connections.
	 * 
	 * @return true, if successful
	 */
	public synchronized boolean stopListen() {
		if (!mIsMediatorAvailable)
			return false;

		if (mMediatorMode == MediatorMode.Server && mServer != null) {
			mServer.stop(false);
			return true;
		}

		return false;
	}

	/**
	 * Open a dialog asking user to make device discoverable on Bluetooth.
	 * 
	 * @param discoverableDuration
	 *            the desired duration of discoverability (in seconds)
	 * @return true, if successful
	 */
	public boolean requestDiscoverable(int discoverableDuration) {
		if (!mIsMediatorAvailable)
			return false;

		if (mAdapter.getScanMode() != BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) {
			Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
			discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, discoverableDuration);
			mContext.startActivityForResult(discoverableIntent, BluetoothMediator.REQUEST_ENABLE_DISCOVERABILITY);

			return true;
		}

		return false;
	}

	/**
	 * Checks Bluetooth availability.
	 * 
	 * @return true, if Bluetooth is available on the device
	 */
	public boolean isBluetoothAvailable() {
		if (!mIsMediatorAvailable)
			return false;

		return mAdapter != null;
	}

	/**
	 * Request enabling of the Bluetooth adapter.
	 * 
	 * @return true, if successful
	 */
	public boolean requestBluetoothEnable() {
		if (!mIsMediatorAvailable || isBluetoothEnabled())
			return false;

		Intent enableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
		mContext.startActivityForResult(enableIntent, REQUEST_ENABLE_BT);

		return true;
	}

	/**
	 * Enable the Bluetooth adapter, if possible.
	 * 
	 * @return true, if successful
	 */
	public boolean bluetoothEnable() {
		if (!mIsMediatorAvailable)
			return false;

		return mAdapter.enable();
	}

	/**
	 * Disable the Bluetooth adapter, if possible.
	 * 
	 * @return true, if successful
	 */
	public boolean bluetoothDisable() {
		if (!mIsMediatorAvailable)
			return false;

		return mAdapter.disable();
	}

	/**
	 * Checks the Bluetooth state.
	 * 
	 * @return true, if Bluetooth is currently enabled and ready for use.
	 */
	public boolean isBluetoothEnabled() {
		if (!mIsMediatorAvailable)
			return false;

		return mAdapter.isEnabled();
	}

	/**
	 * Show the Bluetooth device picker dialog.
	 * 
	 * @return true, if successful
	 */
	public boolean showDeviceList(boolean showAllDeviceTypes) {
		if (!mIsMediatorAvailable || !isBluetoothEnabled())
			return false;

		int deviceType = showAllDeviceTypes ? IBluetoothDevicePicker.FILTER_TYPE_ALL
											: IBluetoothDevicePicker.FILTER_TYPE_TRANSFER;
		// Launch the DeviceListActivity to see devices and do scan
		mContext.startActivity(new Intent(IBluetoothDevicePicker.ACTION_LAUNCH)
				.putExtra(IBluetoothDevicePicker.EXTRA_NEED_AUTH, false)
				.putExtra(IBluetoothDevicePicker.EXTRA_FILTER_TYPE, deviceType)
				.setFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS));

		return true;
	}

	/** The array of bonded (paired) Bluetooth devices. */
	Set<BluetoothDevice> mBondedDevices = new LinkedHashSet<BluetoothDevice>();

	/**
	 * The array of bonded (paired) Bluetooth devices and Bluetooth devices discovered during
	 * current discovery session.
	 */
	Set<BluetoothDevice> mDiscoveredDevices = new LinkedHashSet<BluetoothDevice>();

	/** The array of Bluetooth devices discovered during current discovery session. */
	Set<BluetoothDevice> mNewDiscoveredDevices = new LinkedHashSet<BluetoothDevice>();

	/** Whether the discovery was initiated by {@link startDiscovery}. */
	boolean mIsDiscoveryStartedByUser = false;

	/**
	 * Checks if Bluetooth device discovery is going on.
	 * 
	 * @return true, if discovering
	 */
	public boolean isDiscovering() {
		if (!mIsMediatorAvailable)
			return false;

		return mAdapter.isDiscovering();
	}

	/**
	 * Checks if Bluetooth device is discoverable by other devices.
	 * 
	 * @return true, if discoverable
	 */
	public boolean isDiscoverable() {
		if (!mIsMediatorAvailable)
			return false;

		return mAdapter.getScanMode() == BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE;
	}

	/**
	 * Start discovery of nearby discoverable Bluetooth devices.
	 * 
	 * @return true, if successful
	 */
	public boolean startDiscovery() {
		if (!mIsMediatorAvailable || !isBluetoothEnabled())
			return false;

		stopDiscovery(false);

		// Start the event receiver
		IntentFilter filter = new IntentFilter();
		filter.addAction(BluetoothDevice.ACTION_FOUND);
		filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED);
		filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);

		mContext.registerReceiver(mDiscoveryReceiver, filter);

		return mAdapter.startDiscovery();
	}

	/**
	 * Stop discovery of nearby discoverable Bluetooth devices.
	 * 
	 * @return true, if successful
	 */
	public boolean stopDiscovery() {
		return stopDiscovery(false);
	}

	/**
	 * Stop discovery of nearby discoverable Bluetooth devices.
	 * 
	 * @param forced
	 *            whether to notify Unity
	 * @return true, if successful
	 */
	private boolean stopDiscovery(boolean forced) {
		if (!mIsMediatorAvailable)
			return false;

		try {
			mContext.unregisterReceiver(mDiscoveryReceiver);
		} catch (IllegalArgumentException e) {
			// Well just ignore that, as we won't need that receiver anyway
		}

		mIsDiscoveryStartedByUser = false;

		boolean wasDiscovering = mAdapter.isDiscovering();
		boolean cancelResult = mAdapter.cancelDiscovery();

		if (forced || (wasDiscovering && cancelResult)) {
			BluetoothMediatorUnityEvents.onBluetoothDiscoveryFinished();
		}

		return cancelResult;
	}

	/**
	 * Gets bonded Bluetooth devices.
	 * 
	 * @return the array of bonded Bluetooth devices.
	 */
	public Set<BluetoothDevice> getBondedDevices() {
		if (!mIsMediatorAvailable || !isBluetoothEnabled())
			return null;

		return mAdapter.getBondedDevices();
	}

	/**
	 * Gets Bluetooth devices discovered during current discovery session.
	 * 
	 * @return the array of Bluetooth devices discovered during current discovery session.
	 */
	public Set<BluetoothDevice> getNewDiscoveredDevices() {
		if (!mIsMediatorAvailable || !isBluetoothEnabled())
			return null;

		return mNewDiscoveredDevices;
	}

	/**
	 * Gets bonded (paired) devices and devices discovered during the ongoing discovery session.
	 * 
	 * @return the array of bonded (paired) devices and devices discovered during the ongoing
	 *         discovery session
	 */
	public Set<BluetoothDevice> getDiscoveredDevices() {
		if (!mIsMediatorAvailable || !isBluetoothEnabled())
			return null;

		mDiscoveredDevices.addAll(mAdapter.getBondedDevices());
		return mDiscoveredDevices;
	}

	/**
	 * Gets the current BluetoothDevice.
	 * 
	 * @return current BluetoothDevice, serialized into a string
	 */
	public String getCurrentDevice() {
		if (!mIsMediatorAvailable || !isBluetoothEnabled())
			return null;

		// Set the correspoding class if the device is a tablet
		int deviceClass = isTablet() ? BluetoothClass.Device.COMPUTER_HANDHELD_PC_PDA
									: BluetoothClass.Device.PHONE_SMART;
		String[] result = { mAdapter.getName(),
							mAdapter.getAddress(),
							Integer.toString(BluetoothDevice.BOND_BONDED),
							Integer.toString(deviceClass) };

		return UnityInterop.JavaToStringConverter.implodeArray(result, UnityInterop.JavaToStringConverter.DELIMITER);
	}

	private boolean isTablet() {
		int screenLayout = mContext.getResources().getConfiguration().screenLayout;
		boolean xlarge = ((screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK) == 4);
		boolean large = ((screenLayout & Configuration.SCREENLAYOUT_SIZE_MASK) == Configuration.SCREENLAYOUT_SIZE_LARGE);
		return xlarge || large;
	}

	// Local events

	/**
	 * Called when Bluetooth adapter was disabled.
	 */
	private void onBluetoothDisabled() {
		if (!mIsMediatorAvailable)
			return;

		stop();
	}

	/**
	 * Called when Bluetooth adapter was enabled.
	 */
	private void onBluetoothEnabled() {
		if (!mIsMediatorAvailable)
			return;
	}

	/**
	 * Called from within client/server to notify that connection has been stopped.
	 */
	@Override
	public void onMediatorStopped() {
		mMediatorMode = MediatorMode.None;
	}

	/**
	 * Receives the events of Bluetooth device picker Activity.
	 */
	private class BluetoothDevicePickerReceiver extends BroadcastReceiver implements IBluetoothDevicePicker {

		/*
		 * (non-Javadoc)
		 * @see android.content.BroadcastReceiver#onReceive(android.content.Context,
		 * android.content.Intent)
		 */
		@Override
		public void onReceive(Context context, Intent intent) {
			if (ACTION_DEVICE_SELECTED.equals(intent.getAction())) {
				// context.unregisterReceiver(this);
				BluetoothDevice device = (BluetoothDevice) intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
				BluetoothMediatorUnityEvents.onBluetoothDevicePicked(device);
			}
		}
	}

	/**
	 * Called from context Activity.onActivityResult().
	 * 
	 * @param requestCode
	 *            the request code
	 * @param resultCode
	 *            the result code
	 * @param data
	 *            the data
	 */
	public void onActivityResultProcess(int requestCode, int resultCode, Intent data) {
		switch (requestCode) {
		case BluetoothMediator.REQUEST_ENABLE_BT:
			// When the request to enable Bluetooth returns
			if (resultCode != Activity.RESULT_OK) {
				// User did not enable Bluetooth or an error occured
				BluetoothMediatorUnityEvents.onBluetoothAdapterEnableFailed();
			}
			break;
		case BluetoothMediator.REQUEST_ENABLE_DISCOVERABILITY:
			// When the request to enable Bluetooth discoverability returns
			if (resultCode == Activity.RESULT_CANCELED) {
				// User did not authorized enabling discoverability or an error occured
				BluetoothMediatorUnityEvents.onBluetoothDiscoverabilityEnableFailed();
			} else {
				// User has authorized the discoverability.
				// resultCode contains the duration (in seconds) of discoverability 
				BluetoothMediatorUnityEvents.onBluetoothDiscoverabilityEnabled(resultCode);
			}
			break;
		}
	}

	/**
	 * Receives the Bluetooth adapter change events.
	 */
	private class BluetoothStateChangeReceiver extends BroadcastReceiver {

		/*
		 * (non-Javadoc)
		 * @see android.content.BroadcastReceiver#onReceive(android.content.Context,
		 * android.content.Intent)
		 */
		@Override
		public void onReceive(Context context, Intent intent) {
			final String action = intent.getAction();

			if (action.equals(BluetoothAdapter.ACTION_STATE_CHANGED)) {
				final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE,
														BluetoothAdapter.ERROR);
				switch (state) {
				case BluetoothAdapter.STATE_TURNING_OFF:
				case BluetoothAdapter.ERROR:
					BluetoothMediatorUnityEvents.onBluetoothAdapterDisabled();
					onBluetoothDisabled();
					break;
				case BluetoothAdapter.STATE_ON:
					BluetoothMediatorUnityEvents.onBluetoothAdapterEnabled();
					onBluetoothEnabled();
					break;
				}
			}
		}
	}

	/** The BroadcastReceiver that listens for device discovery events. */
	private final BroadcastReceiver mDiscoveryReceiver = new BroadcastReceiver() {
		@Override
		public void onReceive(Context context, Intent intent) {
			if (!isBluetoothAvailable())
				return;

			String action = intent.getAction();

			// Sending the events to Unity
			if (BluetoothDevice.ACTION_FOUND.equals(action)) {
				BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
				boolean addResultDiscovered = mDiscoveredDevices.add(device);
				boolean addResultNewDiscovered = mNewDiscoveredDevices.add(device);
				boolean isNewDevice = addResultDiscovered || addResultNewDiscovered;

				if (isNewDevice) {
					BluetoothMediatorUnityEvents.onBluetoothDiscoveryDeviceFound(device);
				}
			} else if (BluetoothAdapter.ACTION_DISCOVERY_STARTED.equals(action)) {
				mBondedDevices = new LinkedHashSet<BluetoothDevice>(mAdapter.getBondedDevices());
				mDiscoveredDevices = new LinkedHashSet<BluetoothDevice>(mBondedDevices);
				mNewDiscoveredDevices = new LinkedHashSet<BluetoothDevice>();

				mIsDiscoveryStartedByUser = true;

				BluetoothMediatorUnityEvents.onBluetoothDiscoveryStarted();
			} else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
				stopDiscovery(true);
				// BluetoothMediatorUnityEvents.onBluetoothDiscoveryFinished();
			}

		}
	};

}
