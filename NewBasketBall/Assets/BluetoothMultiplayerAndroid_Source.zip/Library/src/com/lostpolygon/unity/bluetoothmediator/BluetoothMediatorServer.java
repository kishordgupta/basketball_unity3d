/*
 * Copyright (c) 2014, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.bluetoothmediator;

import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

import com.lostpolygon.unity.bluetoothmediator.interop.BluetoothMediatorUnityEvents;
import com.lostpolygon.unity.bluetoothmediator.interop.LogHelper;

/**
 * Class representing the Bluetooth tunneling server.
 */
class BluetoothMediatorServer extends BluetoothMediatorEntityBase {
	/** The incoming connection listening thread. */
	private BluetoothMediatorAcceptThread mBluetoothAcceptThread;

	/**
	 * Instantiates a new Bluetooth multiplayer server.
	 * 
	 * @param bluetoothMediator
	 *            the IBluetoothMediatorCallback interface instance
	 */
	BluetoothMediatorServer(IBluetoothMediatorCallback bluetoothMediator) {
		super(bluetoothMediator);
	}

	/**
	 * Bluetooth connection handling thread.
	 */
	private class BluetoothMediatorConnectedServerThread extends BluetoothMediatorConnectedThread {

		/**
		 * Instantiates a new Bluetooth connection handling thread.
		 * 
		 * @param mSocket
		 *            BluetoothSocket used for connection
		 * @param bluetoothDevice
		 *            remote BluetoothDevice
		 * @param dstHost
		 *            destination hostname used for UDP tunneling
		 * @param dstPort
		 *            destination port used for UDP tunneling
		 * @param srcPort
		 *            source port from which the UDP data will be sent
		 * @param usePacketSeparation
		 *            whether to use packet separation. Must generally be true
		 */
		public BluetoothMediatorConnectedServerThread(BluetoothSocket socket,
														BluetoothDevice bluetoothDevice, String dstHost, int dstPort,
														int srcPort, boolean usePacketSeparation) {
			super(socket, bluetoothDevice, dstHost, dstPort, srcPort, usePacketSeparation);
		}

		/**
		 * Stops the connection and notifies the BluetoothMediatorServer.
		 * 
		 * @see com.lostpolygon.unity.bluetoothmediator.BluetoothMediatorConnectedThread#cancel()
		 */
		public void cancel() {
			super.cancel();

			try {
				BluetoothMediatorServer.this.onDeviceDisconnected(mBluetoothDevice);
			} catch (Exception e) {
				LogHelper.logError("Client - Error while disconnecting", this, e);
			}
		}

	}

	/**
	 * Manages the connected Bluetooth client devices.
	 */
	public final class ClientManager {
		/** The clients HashMap. */
		private final ConcurrentHashMap<Integer, BluetoothMediatorConnection> clients =
				new ConcurrentHashMap<Integer, BluetoothMediatorConnection>();

		/**
		 * Gets the clients HashMap.
		 * 
		 * @return the clients map
		 */
		public synchronized ConcurrentHashMap<Integer, BluetoothMediatorConnection> getClients() {
			return clients;
		}

		/**
		 * Adds the client.
		 * 
		 * @param mSocket
		 *            BluetoothSocket used for connection
		 * @param mDevice
		 *            remote BluetoothDevice
		 * @param mBluetoothConnectedThread
		 *            the BluetoothMediatorConnectedThread instance of a client
		 * @return the client
		 */
		public synchronized BluetoothMediatorConnection addClient(BluetoothSocket socket, BluetoothDevice device,
				BluetoothMediatorConnectedThread bluetoothConnectedThread) {
			synchronized (clients) {
				BluetoothMediatorConnection newClient = new BluetoothMediatorConnection(socket,
						device);
				newClient.setBluetoothConnectedThread(bluetoothConnectedThread);
				clients.put(device.hashCode(), newClient);
				return newClient;
			}

		}
	}

	/** The client manager. */
	private final ClientManager mClientManager = new ClientManager();

	/**
	 * Start listening to to incoming connections.
	 */
	public synchronized void start() {
		if (BluetoothMediator.isVerboseLog())
			LogHelper.log("Server - Starting", this);

		mIsStopped = false;

		// Cancel any thread attempting to make a connection
		if (mBluetoothAcceptThread != null) {
			mBluetoothAcceptThread.cancel();
			mBluetoothAcceptThread = null;
		}

		// Start the thread to listen on a BluetoothServerSocket
		if (mBluetoothAcceptThread == null) {
			mBluetoothAcceptThread = new BluetoothMediatorAcceptThread(this);
			mBluetoothAcceptThread.startListening();
			mBluetoothAcceptThread.start();
		}
	}

	/**
	 * Stops listening to incoming connections
	 * 
	 * @return true, if successful
	 */
	public synchronized boolean stopListening() {
		if (mBluetoothAcceptThread != null) {
			if (BluetoothMediator.isVerboseLog())
				LogHelper.log("Server - stopListening()", this);

			// Canceling the accept thread
			mBluetoothAcceptThread.cancel();

			return true;
		}

		return false;
	}

	/**
	 * Stop the server.
	 * 
	 * @param kickClients
	 *            If true, all connected client will be disconnected. If false - only the listening
	 *            will stop
	 */
	public synchronized void stop(boolean kickClients) {
		mIsStopped = true;

		stopListening();

		if (kickClients) {
			if (BluetoothMediator.isVerboseLog())
				LogHelper.log("Server - Disconnecting clients", this);

			synchronized (mClientManager) {
				for (BluetoothMediatorConnection client : mClientManager.getClients().values()) {
					BluetoothMediatorConnectedThread clientThread = client.getBluetoothConnectedThread();

					if (clientThread != null)
						clientThread.cancel();

					client.setBluetoothConnectedThread(null);
				}
			}

			mMediatorCallback.onMediatorStopped();
		}

	}

	/**
	 * Start the BluetoothMediatorConnectedThread to begin managing a Bluetooth connection.
	 * 
	 * @param mSocket
	 *            The BluetoothSocket on which the connection was made
	 * @param mDevice
	 *            The BluetoothDevice that has been connected
	 */
	public synchronized void onDeviceConnected(BluetoothSocket socket, BluetoothDevice
			device) {

		if (mIsStopped) {
			try {
				socket.close();
			} catch (IOException e) {
				// No need to process the exception when the server has already closed
			}

			return;
		}

		// Create the thread to manage the connection and perform transmissions
		BluetoothMediatorConnectedThread bluetoothConnectedServerThread = new BluetoothMediatorConnectedServerThread(
				socket,
				device,
				mMediatorCallback.getSettings().remoteHost,
				mMediatorCallback.getSettings().remotePort,
				0,
				mMediatorCallback.getSettings().usePacketSeparation);

		// Start the thread
		if (bluetoothConnectedServerThread.isRunning()) {
			bluetoothConnectedServerThread.start();

			// Updating client list
			synchronized (mClientManager) {
				// Checking if client already exists
				BluetoothMediatorConnection existingClient = (BluetoothMediatorConnection) mClientManager.getClients().
						get(device.getAddress());
				if (existingClient != null) {
					// Updating client
					existingClient.getBluetoothConnectedThread().cancel();
					existingClient.setBluetoothConnectedThread(bluetoothConnectedServerThread);

					mClientManager.getClients().put(device.hashCode(), existingClient);

					if (BluetoothMediator.isVerboseLog())
						LogHelper.log("Server - Updated, mDevice address: " + device.getAddress(), this);
				} else {
					// Adding new client
					mClientManager.addClient(socket, device, bluetoothConnectedServerThread);
					BluetoothMediatorUnityEvents.onBluetoothClientConnected(device);

					if (BluetoothMediator.isVerboseLog())
						LogHelper.log("Server - Connected, mDevice address: " + device.getAddress(), this);
				}
			}

			if (BluetoothMediator.isVerboseLog())
				LogHelper.log("Server - Total devices connected: "
								+ Integer.toString(mClientManager.getClients().size()), this);
		}
	}

	/**
	 * Called when a client mDevice disconnects. Removes the mDevice from the client list and
	 * notifies Unity
	 * 
	 * @param mDevice
	 *            The BluetoothDevice that disconnected
	 * @throws RuntimeException
	 */
	public synchronized void onDeviceDisconnected(BluetoothDevice device) throws RuntimeException {
		synchronized (this) {
			synchronized (mClientManager) {
				if (BluetoothMediator.isVerboseLog())
					LogHelper.log("Server - Device " + device.getAddress() + " disconnect phase 1", this);

				BluetoothMediatorConnection disconnectedClient = (BluetoothMediatorConnection) mClientManager.getClients()
						.get(device.getAddress());
				if (disconnectedClient != null) {
					mClientManager.getClients().remove(device.getAddress());

					BluetoothMediatorUnityEvents.onBluetoothClientDisconnected(device);

					if (BluetoothMediator.isVerboseLog()) {
						LogHelper.log("Server - Device " + device.getAddress() + " disconnected", this);
						LogHelper.log("Server - Total devices connected: "
										+ Integer.toString(mClientManager.getClients().size()),
										this);
					}
				} else {
					throw new RuntimeException("Unexistent client disconnected");
				}
			}
		}
	}
}