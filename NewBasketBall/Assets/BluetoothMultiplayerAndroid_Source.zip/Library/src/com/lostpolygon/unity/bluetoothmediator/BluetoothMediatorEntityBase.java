package com.lostpolygon.unity.bluetoothmediator;

public abstract class BluetoothMediatorEntityBase {
	/** The BluetoothMediator interface. */
	protected final IBluetoothMediatorCallback mMediatorCallback;

	/** Whether the entity was stopped. */
	protected boolean mIsStopped = false;

	/**
	 * Instantiates a new Bluetooth base instance.
	 * 
	 * @param bluetoothMediator
	 *            the IBluetoothMediatorCallback interface instance
	 */
	protected BluetoothMediatorEntityBase(IBluetoothMediatorCallback bluetoothMediator) {
		mMediatorCallback = bluetoothMediator;
	}

	/**
	 * Gets the BluetoothMediator interface.
	 * 
	 * @return the IBluetoothMediatorCallback instance
	 */
	public IBluetoothMediatorCallback getMediatorCallback() {
		return mMediatorCallback;
	}
}
