/*
 * Copyright (c) 2014, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.bluetoothmediator;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.lostpolygon.unity.bluetoothmediator.interop.LogHelper;
import com.lostpolygon.unity.bluetoothmediator.udp.IUdpSocketConnectionEventListener;
import com.lostpolygon.unity.bluetoothmediator.udp.UdpSocketConnectionThread;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

/**
 * This thread runs during a connection with a remote device. It handles all incoming and outgoing
 * transmissions.
 */
class BluetoothMediatorConnectedThread extends Thread {

	/** Remote Bluetooth device. */
	protected final BluetoothDevice mBluetoothDevice;

	/** Remote Bluetooth connection socket. */
	protected final BluetoothSocket mBluetoothSocket;

	/** Bluetooth connection input stream. */
	protected final InputStream mBluetoothInStream;

	/** Bluetooth connection output stream. */
	protected final OutputStream mBluetoothOutStream;

	/** The UDP connection manager. */
	protected final UdpSocketConnectionThread mNetworkConnectionManager;

	/** The UDP connection events listener. */
	protected final NetworkConnectionListener mNetworkConnectionListener;

	/** Whether to use packet separation. */
	protected final boolean mUsePacketSeparation;

	/** Whether the tunneling is alive and running. */
	private boolean mIsRunning;

	/** Whether to reassign the dstPort on a incoming datagram. */
	private boolean mIsReassignDstPortOnPacket;

	private static final int INT_SIZE = Integer.SIZE / 8;
	private static final int SHORT_SIZE = INT_SIZE / 2;

	/**
	 * Defines the length of packet header. As UDP datagram can't be longer than 65512 bytes, 2
	 * bytes for header are enough.
	 */
	private static final int HEADER_SIZE = SHORT_SIZE;

	/** Maximum allowed Bluetooth packet size. */
	private static final int BUFFER_SIZE = 32768;

	/**
	 * Listens for UDP connection events.
	 * 
	 * @see NetworkConnectionEvent
	 */
	private class NetworkConnectionListener implements IUdpSocketConnectionEventListener {

		/** Packet buffer. */
		private byte[] mNewBuffer = new byte[BUFFER_SIZE + HEADER_SIZE];

		/** Conversion buffer. */
		private byte[] mConversionBuffer = new byte[SHORT_SIZE];

		/**
		 * Called when a UDP datagram was received.
		 * 
		 * @param buffer
		 *            datagram byte array
		 * @param bufferSize
		 *            the size of the datagram
		 * @param srcPort
		 *            the port from which the datagram came from
		 * @see com.lostpolygon.unity.bluetoothmediator.udp.IUdpSocketConnectionEventListener#onRead(byte[],
		 *      int, int)
		 */
		@Override
		public void onRead(byte[] buffer, int bufferSize, int srcPort) {
			if (mIsReassignDstPortOnPacket) {
				BluetoothMediatorConnectedThread.this.mNetworkConnectionManager.setDstPort(srcPort);
			}

			// Construct the packet and send it via Bluetooth
			if (mUsePacketSeparation) {
				System.arraycopy(buffer, 0, mNewBuffer, HEADER_SIZE, bufferSize);
				// Fill header
				shortIntToByteArray(bufferSize, mConversionBuffer);
				mNewBuffer[0] = mConversionBuffer[0];
				mNewBuffer[1] = mConversionBuffer[1];

				BluetoothMediatorConnectedThread.this.bluetoothWrite(mNewBuffer, 0, HEADER_SIZE + bufferSize);
			} else {
				BluetoothMediatorConnectedThread.this.bluetoothWrite(buffer, 0, bufferSize);
			}

		}

		/**
		 * Called when some socket failure occurs. This generally means connection is interrupted.
		 */
		@Override
		public void onSocketFailure() {
			LogHelper.logError("Connection - onSocketFailure()", this, null);
			cancel();
		}
	}

	/**
	 * Instantiates a new bluetooth mediator connected thread.
	 * 
	 * @param socket
	 *            BluetoothSocket used for connection
	 * @param bluetoothDevice
	 *            remote BluetoothDevice
	 * @param dstHost
	 *            destination hostname used for UDP tunneling
	 * @param dstPort
	 *            destination port used for UDP tunneling
	 * @param srcPort
	 *            source port from which the UDP data will be sent
	 * @param usePacketSeparation
	 *            whether to use packet separation. Must generally be true
	 */
	public BluetoothMediatorConnectedThread(BluetoothSocket socket,
											BluetoothDevice bluetoothDevice,
											String dstHost,
											int dstPort,
											int srcPort,
											boolean usePacketSeparation) {
		super("BluetoothMediatorConnectedThread [" + bluetoothDevice.getAddress() + "]");
		setDaemon(true);

		mBluetoothDevice = bluetoothDevice;

		if (BluetoothMediator.isVerboseLog())
			LogHelper.log("Connection - Create BluetoothMediatorConnectedThread", this);

		mIsRunning = true;
		mIsReassignDstPortOnPacket = false;

		// Create UDP connection
		mUsePacketSeparation = usePacketSeparation;
		mNetworkConnectionListener = new NetworkConnectionListener();
		mNetworkConnectionManager = new UdpSocketConnectionThread(mNetworkConnectionListener,
				dstHost,
				dstPort,
				srcPort);

		mNetworkConnectionManager.initSocket();
		if (!mNetworkConnectionManager.isDisconnected()) {
			if (BluetoothMediator.isVerboseLog())
				LogHelper.log("Connection - Created UDP socket", this);
		} else {
			LogHelper.logError("Connection - UDP socket creation error", this, null);
			mIsRunning = false;

			mBluetoothSocket = socket;
			mBluetoothInStream = null;
			mBluetoothOutStream = null;

			cancel();
			return;
		}

		if (!mNetworkConnectionManager.isDisconnecting()) {
			mNetworkConnectionManager.setName(mNetworkConnectionManager.getClass().getSimpleName() + " ["
												+ mBluetoothDevice.getAddress() + "]");
			// Starting the UDP datagram receival loop
			mNetworkConnectionManager.start();
		}

		// Setting Bluetooth stream
		mBluetoothSocket = socket;
		InputStream tmpIn = null;
		OutputStream tmpOut = null;

		// Get the BluetoothSocket input and output streams
		try {
			tmpIn = socket.getInputStream();
			tmpOut = socket.getOutputStream();
		} catch (IOException e) {
			LogHelper.logError("Connection - Temp streams not created", this, e);
		}

		mBluetoothInStream = tmpIn;
		mBluetoothOutStream = tmpOut;
	}

	/**
	 * Main thread. Receives data from Bluetooth and retransmits it over UDP.
	 * 
	 * @see java.lang.Thread#run()
	 */
	public synchronized void run() {
		if (!isRunning())
			return;
		if (BluetoothMediator.isVerboseLog())
			LogHelper.log("Connection - Start ConnectedThread", this);

		byte[] buffer = new byte[BUFFER_SIZE];
		int readBytes;
		boolean packetIsReceivingSize = true;
		int packetSize = HEADER_SIZE;
		int packetReadBytes = 0;

		// Keep listening to the InputStream while connected
		while (true) {
			try {
				// Read from the InputStream
				if (mUsePacketSeparation) {
					while ((readBytes = mBluetoothInStream.read(buffer, packetReadBytes, packetSize - packetReadBytes)) != -1) {
						packetReadBytes += readBytes;

						// Read packet size
						if (packetIsReceivingSize) {
							if (packetReadBytes == HEADER_SIZE) {
								packetSize = byteArrayToShortInt(buffer);
								if (packetSize > BUFFER_SIZE) {
									throw new IOException("Connection - Erroneous packet received: packetSize > BUFFER_SIZE. This should not be happening.");
								}
								packetIsReceivingSize = false;
								packetReadBytes = 0;
							}
						}
						// Read packet
						else {
							if (packetReadBytes == packetSize) {
								// Send packet
								onBluetoothRead(buffer, 0, packetSize);

								// Start reading another packet
								packetSize = HEADER_SIZE;
								packetIsReceivingSize = true;
								packetReadBytes = 0;
							}
						}
					}
				} else {
					while ((readBytes = mBluetoothInStream.read(buffer)) != -1) {
						// Send packet
						onBluetoothRead(buffer, 0, readBytes);
					}
				}

			} catch (IOException e) {
				// if (BluetoothMediator.isVerboseLog())
				LogHelper.log("Connection - Disconnected", this);

				if (mIsRunning)
					cancel();

				break;
			} catch (Exception e) {
				LogHelper.logError("Connection - Unexpected exception", this, e);
				if (mIsRunning)
					cancel();

				break;
			}
		}

		if (BluetoothMediator.isVerboseLog())
			LogHelper.log("Connection - End ConnectedThread", this);
	}

	/**
	 * Called when a data packet is received via Bluetooth.
	 * 
	 * @param buffer
	 *            Received bytes
	 * @param length
	 *            the read packet size
	 */
	public void onBluetoothRead(byte[] buffer, int offset, int length) {
		mNetworkConnectionManager.send(buffer, offset, length);
	}

	/**
	 * Write to the Bluetooth stream.
	 * 
	 * @param buffer
	 *            The bytes to write
	 * @param length
	 *            the buffer size
	 * @return true, if successful
	 */
	public boolean bluetoothWrite(byte[] buffer, int offset, int length) {
		try {
			if (length > 0)
				mBluetoothOutStream.write(buffer, offset, length);

			return true;
		} catch (IOException e) {
			LogHelper.logError("Connection - Exception during write", this, e);
		}

		return false;
	}

	/**
	 * Cancels the tunneled connection.
	 */
	public void cancel() {
		if (!mIsRunning)
			return;

		mIsRunning = false;

		try {
			if (BluetoothMediator.isVerboseLog())
				LogHelper.log("Connection - BTSocket close() start", this);
			if (mBluetoothSocket != null) {
				mBluetoothSocket.close();
				mBluetoothInStream.close();
				mBluetoothOutStream.close();
			}

			if (BluetoothMediator.isVerboseLog())
				LogHelper.log("Connection - BTSocket close() successful", this);
		} catch (IOException e) {
			LogHelper.logError("Connection - BTSocket close() failed", this, e);
		}

		if (mNetworkConnectionManager != null)
			mNetworkConnectionManager.stopConnection();
	}

	/**
	 * Sets whether to reassign the dstPort on a incoming datagram
	 */
	public void setReassignDstPortOnPacket() {
		mIsReassignDstPortOnPacket = true;
	}

	/**
	 * Checks the connection status.
	 * 
	 * @return true, if the tunneled connection is alive and running
	 */
	public boolean isRunning() {
		return mIsRunning;
	}

	/**
	 * Converts a two-byte int into a byte[].
	 * 
	 * @param value
	 *            the value
	 * @return the byte[]
	 */
	public static final void shortIntToByteArray(int value, byte[] buffer) {
		buffer[0] = (byte) (value >>> 8);
		buffer[1] = (byte) (value);
	}

	/**
	 * Converts an length of 2 byte[] into an int.
	 * 
	 * @param bytes
	 *            the bytes
	 * @return the int
	 */
	public static final int byteArrayToShortInt(byte[] bytes) {
		return 0 << 24 | (0 & 0xFF) << 16 | (bytes[0] & 0xFF) << 8 | (bytes[1] & 0xFF);
	}

}
