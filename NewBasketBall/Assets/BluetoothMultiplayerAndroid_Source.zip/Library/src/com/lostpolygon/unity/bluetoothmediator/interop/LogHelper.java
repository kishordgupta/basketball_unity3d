/*
 * Copyright (c) 2014, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.bluetoothmediator.interop;

import android.util.Log;

/**
 * Helper class for logcat logs.
 */
public class LogHelper {
	public final static String LOG_TAG = "BluetoothMultiplayer";
	public final static boolean INCLUDE_CLASS = false;

	public static void log(String text, String title) {
		if (INCLUDE_CLASS)
			Log.d(LOG_TAG, title + ": " + text);
		else
			Log.d(LOG_TAG, text);
	}

	public static void log(String text, Class<?> logClass) {
		log(text, logClass.getSimpleName());
	}

	public static void log(String text, Object object) {
		log(text, object.getClass().getSimpleName());
	}

	public static void logError(String text, String title, Throwable throwable) {
		if (INCLUDE_CLASS)
			Log.e(LOG_TAG, title + ": " + text, throwable);
		else
			Log.e(LOG_TAG, text, throwable);
	}

	public static void logError(String text, Class<?> logClass, Throwable throwable) {
		logError(text, logClass.getSimpleName(), throwable);
	}

	public static void logError(String text, Object object, Throwable throwable) {
		logError(text, object.getClass().getSimpleName(), throwable);
	}
	
}
