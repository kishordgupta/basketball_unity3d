/*
 * Copyright (c) 2014, Lost Polygon. All rights reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 * 
 * This file is subject to Asset Store Terms of Service and EULA.
 * Please see http://unity3d.com/company/legal/as_terms for more information.
 */

package com.lostpolygon.unity.bluetoothmediator.udp;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;

import com.lostpolygon.unity.bluetoothmediator.BluetoothMediator;
import com.lostpolygon.unity.bluetoothmediator.interop.LogHelper;

/**
 * This class manages the UDP socket connection.
 */
public class UdpSocketConnectionThread extends Thread {

	/** UDP mSocket being managed. */
	private DatagramSocket mSocket = null;

	/** Destination host name. */
	private String mDstHost;

	/** Destination port. */
	private int mDstPort;

	/** Destination host address. */
	private InetAddress mDstAddress;

	/** Source port to send data from */
	private int mSrcPort;

	/**
	 * Socket event mListener (onRead and onSocketFailure).
	 */
	private final IUdpSocketConnectionEventListener mListener;

	/**
	 * Value indicating whether the UDP mSocket is working and active.
	 */
	private boolean mIsRunning = false;

	/**
	 * Value indicating whether the mSocket in the process of being closed.
	 */
	private boolean mIsDisconnecting = false;

	/** Value indicating whether the mSocket is closed. */
	private boolean mIsDisconnected = true;

	/**
	 * Constant value indicating the maximum packet size. While UDP packet technically can be up to
	 * 65512 bytes, that usually won't occur in a typical game.
	 */
	private static final int BUFFER_SIZE = 65000;

	/**
	 * Instantiates a new UDP mSocket connection manager.
	 * 
	 * @param mListener
	 *            Socket event mListener (onRead and onSocketFailure)
	 * @param dstName
	 *            Destination host name
	 * @param mDstPort
	 *            Destination port
	 * @param mSrcPort
	 *            Source port to send data from
	 */
	public UdpSocketConnectionThread(IUdpSocketConnectionEventListener listener, String dstName,
										int dstPort, int srcPort) {
		super("UdpSocketConnectionManager");
		mDstHost = dstName;
		mDstPort = dstPort;
		mSrcPort = srcPort;
		mListener = listener;
	}

	/**
	 * Sets the destination port.
	 * 
	 * @param mDstPort
	 *            the new destination port
	 */
	public void setDstPort(int dstPort) {
		mDstPort = dstPort;
	}

	/**
	 * Initializes the socket
	 * 
	 * @return port number of created socket
	 */
	public int initSocket() {
		stopConnection(false);

		try {
			// Select a random port
			// if we haven't set any particular port
			if (mSrcPort <= 0)
				mSrcPort = findFreePort();

			// Setting up the socket
			mSocket = new DatagramSocket(null);
			mSocket.setBroadcast(false);
			mSocket.setReceiveBufferSize(BUFFER_SIZE);
			mSocket.setSendBufferSize(BUFFER_SIZE);
			mSocket.bind(new InetSocketAddress(Inet4Address.getByName("0.0.0.0"), mSrcPort));
			mDstAddress = InetAddress.getByName(mDstHost);

			mIsDisconnected = false;

			return mSrcPort;
		} catch (IOException e) {
			// Stopping the connection in case of exception.
			if (BluetoothMediator.isVerboseLog()) {
				LogHelper.logError("UDP - IOException in initSocket()", this, e);
			}

			stopConnection(true);
			return -1;
		}
	}

	/**
	 * Send the byte array to the mDstPort.
	 * 
	 * @param buffer
	 *            the packet byte array
	 * @param length
	 *            the size of the packet
	 * @return true, if successful
	 */
	public boolean send(byte[] buffer, int offset, int length) {
		if (mIsRunning && !mIsDisconnecting) {
			try {
				DatagramPacket sentPacket = new DatagramPacket(
						buffer,
						offset,
						length,
						mDstAddress,
						mDstPort);

				mSocket.send(sentPacket);
			} catch (IOException e) {
				stopConnection(true);

				LogHelper.logError("UDP - Error while sending", this, e);
				return false;
			}

			return true;
		} else {
			return false;
		}
	}

	/**
	 * The main packet processing loop.
	 * 
	 * @see java.lang.Thread#run()
	 */
	public void run() {
		if (mSocket != null && mSocket.isBound()) {
			if (BluetoothMediator.isVerboseLog())
				LogHelper.log("UDP - Entering run() loop", this);

			try {
				mIsRunning = true;

				byte[] buffer = new byte[BUFFER_SIZE];

				// The loop runs until disconnected or some error happened
				while (mIsRunning && !isDisconnecting() && mListener != null) {
					DatagramPacket receivedPacket = new DatagramPacket(buffer, buffer.length);

					// Receiving the packet
					mSocket.receive(receivedPacket);
					// Passing the received packet to the mListener
					mListener.onRead(receivedPacket.getData(), receivedPacket.getLength(), receivedPacket.getPort());
				}
			} catch (Exception e) {
				// Stopping the connection on any exception
				if (BluetoothMediator.isVerboseLog()) {
					LogHelper.log("UDP - Exited run() loop", UdpSocketConnectionThread.this);
				}

				try {
					if (mIsRunning && !mIsDisconnecting) {
						stopConnection(true);
					}
				} catch (Exception er) {
					LogHelper.logError("UDP - Exception while stopping connection", UdpSocketConnectionThread.this, e);
				}
			} finally {
				mIsRunning = false;
			}
		}
	}

	/**
	 * Stops the connections and closes the mSocket gracefully.
	 * 
	 * @param notifyListener
	 *            Whether to notify the mListener that the connection was terminated
	 */
	private void stopConnection(boolean notifyListener) {
		mIsDisconnecting = true;
		if (mSocket != null && !mSocket.isClosed()) {
			mSocket.close();
		}

		mSocket = null;

		mIsRunning = false;
		mIsDisconnecting = false;
		mIsDisconnected = true;

		if (notifyListener) {
			mListener.onSocketFailure();
		}
	}

	/**
	 * Stops the connections and closes the socket gracefully. There is no need to notify the
	 * mListener, as only mListener should call this method.
	 */
	public void stopConnection() {
		stopConnection(false);
	}

	/**
	 * Checks if the UDP mSocket is working and active.
	 * 
	 * @return true, if the UDP mSocket is working and active.
	 */
	public boolean isRunning() {
		return mIsRunning;
	}

	/**
	 * Checks if the mSocket in the process of being closed.
	 * 
	 * @return true, if the mSocket in the process of being closed.
	 */
	public boolean isDisconnecting() {
		return mIsDisconnecting;
	}

	/**
	 * Checks if the mSocket is closed.
	 * 
	 * @return true, if the mSocket is closed.
	 */
	public boolean isDisconnected() {
		return mIsDisconnected;
	}

	/**
	 * Finds a free random port. This is done by creating a ServerSocket with random port,
	 * retrieving the port number, and closing the mSocket.
	 * 
	 * @return the free port number
	 * @throws IOException
	 *             Signals that an I/O exception has occurred. This could only possibly happen if
	 *             there are no free ports.
	 */
	private int findFreePort() {
		ServerSocket socket = null;
		try {
			socket = new ServerSocket(0);
			return socket.getLocalPort();
		} catch (Exception e) {
		} finally {
			if (socket != null) {
				try {
					socket.close();
				} catch (Exception e) {
				}
			}
		}
		return -1;
	}

}
